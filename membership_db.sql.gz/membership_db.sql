-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2017 at 02:59 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `membership_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `mem_accounts`
--

CREATE TABLE `mem_accounts` (
  `acct_no` int(11) NOT NULL,
  `acct_id` int(11) NOT NULL,
  `acct_username` varchar(60) NOT NULL,
  `acct_password` varchar(60) NOT NULL,
  `acct_date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `acct_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mem_accounts`
--

INSERT INTO `mem_accounts` (`acct_no`, `acct_id`, `acct_username`, `acct_password`, `acct_date_added`, `acct_status`) VALUES
(1, 1, 'edizonv', '$2y$10$KHCg.RugIbcm.UtJdvmugOkX/wT7cQj8wvK.zBy.jJv6FGCSnXW1q', '2017-09-27 02:38:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mem_profile`
--

CREATE TABLE `mem_profile` (
  `user_id` int(11) NOT NULL,
  `user_firstname` varchar(30) NOT NULL,
  `user_lastname` varchar(30) NOT NULL,
  `user_date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mem_profile`
--

INSERT INTO `mem_profile` (`user_id`, `user_firstname`, `user_lastname`, `user_date_added`, `user_status`) VALUES
(1, 'edizon', 'villegas', '2017-10-04 05:20:07', 1),
(2, 'test', 'again', '2017-10-04 05:20:07', 1),
(3, 'juan', 'dela cruz', '2017-10-04 05:20:07', 1),
(4, 'sir', 'mam', '2017-10-04 05:20:07', 1),
(5, 'pedro', 'juan', '2017-10-04 05:20:07', 1),
(6, 'ian', 'cartojano.', '2017-10-04 05:20:07', 1),
(7, 'test', 'again!', '2017-10-04 05:20:07', 1),
(8, 'test', 'ddddd', '2017-10-04 05:20:07', 1),
(9, 'dd', 'ddd', '2017-10-04 05:20:07', 1),
(10, 'dd', 'ddd', '2017-10-04 05:20:07', 1),
(11, 'dd', 'ddd', '2017-10-04 05:20:07', 1),
(12, 'dd', 'dd', '2017-10-04 05:20:07', 1),
(13, 'dd', 'dd', '2017-10-04 05:20:07', 1),
(14, '33', '44', '2017-10-04 00:58:54', 1),
(15, '11', '22', '2017-10-04 05:20:07', 1),
(16, 'dd', 'ddd', '2017-10-04 00:58:54', 1),
(17, 'dd', 'ddd', '2017-10-05 06:41:13', 0),
(18, 'dd', 'dd', '2017-10-05 05:03:05', 0),
(19, 'test', 'dd', '2017-10-05 02:27:51', 0),
(20, '<script>alert()</script>', 'test', '2017-10-04 06:38:37', 0),
(21, '11', '22', '2017-10-04 06:38:39', 0),
(22, '<strong>test</strong>', '<strong>test</strong>', '2017-10-04 06:38:34', 0),
(23, 'test', 'test', '2017-10-05 08:30:49', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mem_accounts`
--
ALTER TABLE `mem_accounts`
  ADD PRIMARY KEY (`acct_no`);

--
-- Indexes for table `mem_profile`
--
ALTER TABLE `mem_profile`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mem_accounts`
--
ALTER TABLE `mem_accounts`
  MODIFY `acct_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `mem_profile`
--
ALTER TABLE `mem_profile`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
